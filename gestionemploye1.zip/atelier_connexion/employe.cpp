#include "employe.h"
#include<QSqlQuery>
#include<QDebug>
#include<QSqlQueryModel>
#include<QObject>
#include <QtDebug>
#include <iostream>
#include "connection.h"
using namespace std;
Employe::Employe()
{
    cin=0; nom=" " ; prenom=" "; role=" "; numtel=" "; adresse=" "; mail=" ";



}
Employe::Employe(int cin , QString nom , QString prenom ,QString role , QString mail , QString adresse , QString numtel )
{
    this->cin=cin;
    this->nom=nom;
    this->prenom=prenom;
    this->role=role;
    this->numtel=numtel;
    this->adresse=adresse;
    this->mail=mail;

}
int Employe:: getcin(){return cin ;}
QString Employe::  getnom(){return nom ;};
QString Employe::  getrole(){return role ;}
QString Employe::  getmail(){return mail ;}
QString Employe::  getnumtel(){return numtel ;}
QString Employe::  getadresse(){return adresse ;}
QString Employe:: getprenom(){return prenom ;}
void Employe:: setcin(int cin){this->cin=cin;}
void Employe:: setnom(QString nom){this->nom=nom;}
void Employe:: setprenom(QString prenom){this->prenom=prenom ; }
void Employe:: setrole(QString role){this->role=role;}
void Employe:: setmail(QString mail){this->mail=mail;}
void Employe:: setnumtel(QString numtel){this->numtel=numtel;}
void Employe:: setadresse(QString adresse){this->adresse=adresse;}
bool Employe::ajouter()
{



    QSqlQuery query;

          query.prepare("INSERT INTO EMPLOYE (prenom, nom , cin ,role , adresse ,numtel , mail) "
                        "VALUES ( :PRENOM, :NOM ,:CIN, :ROLE ,:ADRESSE ,:NUMTEL ,:MAIL)");
          query.bindValue(":CIN", cin);
          query.bindValue(":PRENOM", prenom);
          query.bindValue(":NOM", nom);
          query.bindValue(":ROLE", role);
          query.bindValue(":MAIL", mail);
          query.bindValue(":ADRESSE", adresse);
          query.bindValue(":NUMTEL", numtel);
          query.exec();
}

QSqlQueryModel* Employe::afficher()
{

     QSqlQueryModel* model=new QSqlQueryModel();

           model->setQuery(" SELECT * FROM EMPLOYE ");
           model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
           model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM"));
           model->setHeaderData(3, Qt::Horizontal, QObject::tr("PRENOM"));
           model->setHeaderData(4, Qt::Horizontal, QObject::tr("ROLE"));
           model->setHeaderData(5, Qt::Horizontal, QObject::tr("MAIL"));
           model->setHeaderData(6, Qt::Horizontal, QObject::tr("NUMTEL"));
           model->setHeaderData(7, Qt::Horizontal, QObject::tr("ADRESSE"));

     return model;
 }


bool Employe::supprimer(int cin)
{
    QSqlQuery query;

          query.prepare(" Delete from EMPLOYE where cin=:CIN");
          query.bindValue(":CIN" , cin);
           return query.exec();
}


bool Employe::modifier(int cin)
 {


   QSqlQuery query;


    query.prepare("update  EMPLOYE set CIN=:cin,  NOM=:nom, PRENOM=:prenom,NUMTEL=:numtel , ROLE=:role , MAIL=:mail , ADRESSE=:adresse  where CIN=:cin " );
    query.bindValue(":cin", cin);
         query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
     query.bindValue(":numtel", numtel);
     query.bindValue(":role", role);
     query.bindValue(":mail", mail);
     query.bindValue(":adresse", adresse);


   return  query.exec();

}

