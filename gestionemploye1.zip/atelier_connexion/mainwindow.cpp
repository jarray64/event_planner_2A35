#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "employe.h"
#include <QMessageBox>
#include <QSqlDatabase>
#include <QIntValidator>
#include <QSqlQueryModel>
#include <QDebug>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)

{

    ui->setupUi(this);
ui->le_cin_2->setValidator(new QIntValidator(100,9999999,this));
ui->tab_empolye->setModel(E.afficher());

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pb_ajouter_clicked()
{
    int cin= ui->le_cin_2->text().toInt();
    QString nom=ui->le_nom_2->text();
    QString prenom=ui->le_prenom_2->text();
    QString role=ui->le_role_2->text();
    QString mail=ui->le_mail_2->text();
    QString numtel=ui->le_num_2->text();
    QString adresse=ui->le_adresse_2->text();
    E = Employe(cin,nom,prenom,role,mail,numtel,adresse);

    bool test=E.ajouter();
    if(test){

          ui->tab_empolye->setModel(E.afficher());

          QMessageBox::information(nullptr,"ajout","done !");
    }
      else{
          QMessageBox::critical(nullptr,"ajout","failed !");
}


    }



void MainWindow::on_tab_empolye_activated(const QModelIndex &index){}

void MainWindow::on_pb_supprimer_clicked()
{
    Employe E ; E.setcin(ui->le_cin_sup->text().toInt());
    bool test=E.supprimer(E.getcin());
    if(test){

          ui->tab_empolye->setModel(E.afficher());

          QMessageBox::information(nullptr,QObject::tr(" OK"),
                                   QObject::tr("Suppression effectuée\n"
                                               "Click Cancel to exit."),QMessageBox::Cancel);
          ui->tab_empolye->setModel(E.afficher());

    }
      else{
          QMessageBox::critical(nullptr,QObject::tr("Not OK"),
                                QObject::tr("Suppression non effectué\n"
                                            "Click Cancel to exit."),QMessageBox::Cancel);
          ui->le_cin_2->clear();
          ui->le_nom_2->clear();
          ui->le_role_2->clear();
          ui->le_adresse_2->clear();
          ui->le_mail_2->clear();
          ui->le_num_2->clear();
          ui->le_prenom_2->clear();

}}

void MainWindow::on_tabWidget_currentChanged(int index)
{
    ui->tab_empolye->setModel(E.afficher());
}






void MainWindow::on_pb_modif_clicked()
{

    int cin= ui->le_cin_2->text().toInt();
    QString nom=ui->le_nom_2->text();
  QString prenom=ui->le_prenom_2->text();
    QString role=ui->le_role_2->text();
    QString mail=ui->le_mail_2->text();
    QString numtel=ui->le_num_2->text();
   QString adresse=ui->le_adresse_2->text();
   E = Employe(cin,nom,prenom,role,mail,numtel,adresse);

    bool test=E.modifier(cin);
    if(test)
        {

            QMessageBox::information(nullptr,QObject::tr(" OK"),
                                     QObject::tr("Modification effectuée\n"
                                                 "Click Cancel to exit."),QMessageBox::Cancel);

ui->tab_empolye->setModel(E.afficher());
        }
        else
           QMessageBox::critical(nullptr,QObject::tr("Not OK"),
                                     QObject::tr("Modification non effectué\n"
                                                 "Click Cancel to exit."),QMessageBox::Cancel);
        ui->le_cin_2->clear();
        ui->le_nom_2->clear();
        ui->le_role_2->clear();
        ui->le_adresse_2->clear();
        ui->le_mail_2->clear();
        ui->le_num_2->clear();
        ui->le_prenom_2->clear();
}




