#include "connection.h"

Connection::Connection()
{

}

bool Connection::createconnect()
{

QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("projet_2A");
db.setHostName("localhost");
db.setUserName("eya");//inserer nom de l'utilisateur
db.setPassword("eya");//inserer mot de passe de cet utilisateur

if (!db.isOpen())
db.open();

    return  db.isOpen();
}
