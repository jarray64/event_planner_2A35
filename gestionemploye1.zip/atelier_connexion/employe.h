#ifndef ETUDIANT_H
#define ETUDIANT_H
#include<QString>
#include<QSqlQueryModel>
#include<QtDebug>
#include <QSqlQueryModel>

class Employe
{
public:
    Employe();
    Employe(int , QString , QString ,QString ,QString , QString ,QString );
    int getcin();
    QString getnom();
    QString getmail();
    QString getadresse();
    QString getnumtel();
    QString getrole();
    QString getprenom();
    void setcin(int);
    void setnom(QString);
    void setprenom(QString);
    void setmail(QString);
    void setadresse(QString);
    void setnumtel(QString);
    void setrole(QString);
    bool ajouter();
    QSqlQueryModel* afficher();
    bool supprimer(int);
    bool modifier (int cin);

private :

    QString nom , prenom , role , numtel , mail , adresse ;
    int cin;
};

#endif // ETUDIANT_H
